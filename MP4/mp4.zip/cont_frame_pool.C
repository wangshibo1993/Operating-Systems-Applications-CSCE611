/*
 File: ContFramePool.C
 
 Author:
 Date  : 
 
 */

/*--------------------------------------------------------------------------*/
/* 
 POSSIBLE IMPLEMENTATION
 -----------------------

 The class SimpleFramePool in file "simple_frame_pool.H/C" describes an
 incomplete vanilla implementation of a frame pool that allocates 
 *single* frames at a time. Because it does allocate one frame at a time, 
 it does not guarantee that a sequence of frames is allocated contiguously.
 This can cause problems.
 
 The class ContFramePool has the ability to allocate either single frames,
 or sequences of contiguous frames. This affects how we manage the
 free frames. In SimpleFramePool it is sufficient to maintain the free 
 frames.
 In ContFramePool we need to maintain free *sequences* of frames.
 
 This can be done in many ways, ranging from extensions to bitmaps to 
 free-lists of frames etc.
 
 IMPLEMENTATION:
 
 One simple way to manage sequences of free frames is to add a minor
 extension to the bitmap idea of SimpleFramePool: Instead of maintaining
 whether a frame is FREE or ALLOCATED, which requires one bit per frame, 
 we maintain whether the frame is FREE, or ALLOCATED, or HEAD-OF-SEQUENCE.
 The meaning of FREE is the same as in SimpleFramePool. 
 If a frame is marked as HEAD-OF-SEQUENCE, this means that it is allocated
 and that it is the first such frame in a sequence of frames. Allocated
 frames that are not first in a sequence are marked as ALLOCATED.
 
 NOTE: If we use this scheme to allocate only single frames, then all 
 frames are marked as either FREE or HEAD-OF-SEQUENCE.
 
 NOTE: In SimpleFramePool we needed only one bit to store the state of 
 each frame. Now we need two bits. In a first implementation you can choose
 to use one char per frame. This will allow you to check for a given status
 without having to do bit manipulations. Once you get this to work, 
 revisit the implementation and change it to using two bits. You will get 
 an efficiency penalty if you use one char (i.e., 8 bits) per frame when
 two bits do the trick.
 
 DETAILED IMPLEMENTATION:
 
 How can we use the HEAD-OF-SEQUENCE state to implement a contiguous
 allocator? Let's look a the individual functions:
 
 Constructor: Initialize all frames to FREE, except for any frames that you 
 need for the management of the frame pool, if any.
 
 get_frames(_n_frames): Traverse the "bitmap" of states and look for a 
 sequence of at least _n_frames entries that are FREE. If you find one, 
 mark the first one as HEAD-OF-SEQUENCE and the remaining _n_frames-1 as
 ALLOCATED.

 release_frames(_first_frame_no): Check whether the first frame is marked as
 HEAD-OF-SEQUENCE. If not, something went wrong. If it is, mark it as FREE.
 Traverse the subsequent frames until you reach one that is FREE or 
 HEAD-OF-SEQUENCE. Until then, mark the frames that you traverse as FREE.
 
 mark_inaccessible(_base_frame_no, _n_frames): This is no different than
 get_frames, without having to search for the free sequence. You tell the
 allocator exactly which frame to mark as HEAD-OF-SEQUENCE and how many
 frames after that to mark as ALLOCATED.
 
 needed_info_frames(_n_frames): This depends on how many bits you need 
 to store the state of each frame. If you use a char to represent the state
 of a frame, then you need one info frame for each FRAME_SIZE frames.
 
 A WORD ABOUT RELEASE_FRAMES():
 
 When we releae a frame, we only know its frame number. At the time
 of a frame's release, we don't know necessarily which pool it came
 from. Therefore, the function "release_frame" is static, i.e., 
 not associated with a particular frame pool.
 
 This problem is related to the lack of a so-called "placement delete" in
 C++. For a discussion of this see Stroustrup's FAQ:
 http://www.stroustrup.com/bs_faq2.html#placement-delete
 
 */
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "cont_frame_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   C o n t F r a m e P o o l */
/*--------------------------------------------------------------------------*/
ContFramePool* ContFramePool::head_of_list=NULL;
unsigned int ContFramePool::number_of_framepools=0;

ContFramePool::ContFramePool(unsigned long _base_frame_no,
                             unsigned long _n_frames,
                             unsigned long _info_frame_no,
                             unsigned long _n_info_frames)
{
    // TODO: IMPLEMENTATION NEEEDED!

    // In simpleframepool, Bitmap must fit in a single frame. But, we don't have to
    //assert(_n_frames <= FRAME_SIZE * 4);
    base_frame_no = _base_frame_no;
    nframes = _n_frames;
    nFreeFrames = _n_frames;
    info_frame_no = _info_frame_no;
    n_info_frames=_n_info_frames;
    // If _info_frame_no is zero then we keep management info in the first
    //frame, else we use the provided frame to keep management info
              
    if(number_of_framepools==0)
    {
       head_of_list=this;
       this->next=NULL;
       number_of_framepools++;
    }
    else 
    {
    ContFramePool *p=head_of_list;
   /* while((p->next)!=NULL)
    p=p->next;
    p->next=this; */
    while(p->next != NULL)
         {
            assert((_base_frame_no >= (p->base_frame_no+nframes))||(_base_frame_no+_n_frames)<= (p->base_frame_no));
            p=p->next;
       
         }
    assert((_base_frame_no >= (p->base_frame_no+p->nframes))||(_base_frame_no+_n_frames)<= (p->base_frame_no));
    //We should make sure the last existed framepool in the list also does not overlap with the new framepool
    p->next=this;
    this->next=NULL;
    number_of_framepools++;

    }
   //First we should make sure the new framepool does not overlap with other framepools existed           
               
                      
                
    if(info_frame_no == 0)
    {
       bitmap = (unsigned char *) (base_frame_no * FRAME_SIZE);
    } 
    else
    {
       bitmap = (unsigned char *) (info_frame_no * FRAME_SIZE);
    }
    
    // Number of frames must be "fill" the bitmap!
    assert ((nframes % 4 ) == 0);
    //nframes=(nframes%4)>0 ? nframes+4-(nframes%4) : nframes; We can use this statement to make nframes fill bitmap
    
    // Everything ok. Proceed to mark all bits in the bitmap. We mark the first two bits
    // as 01 which means HEAD OF SEQUENCE, and other two bits as 10, ALLOCATED
    
    for(unsigned int i=0; i*4 < nframes; i++) 
    {
       bitmap[i] = 0x0;
    }
    
    // Mark the first frame as being used if it is being used  01 00 00 00
    if(info_frame_no == 0)
    {
       bitmap[0]=0x40;
       nFreeFrames--;
       for(unsigned int i=1; i<_n_info_frames; i++)
       {  //If we need more than one frame to manage information, we do this
          unsigned int bitmap_index=i/4;
          unsigned char j=(0x80)>>(2*(i%4)); // 10 00 00 00
          bitmap[bitmap_index] =(bitmap[bitmap_index])|j;
          nFreeFrames--;
       }  
    }
    Console::puts("nframes ="); Console::puti(nframes); Console::puts("\n"); //Debug
   // Console::puts(" nFreeFrames ="); Console::puti(nFreeFrames); Console::puts("\n"); //Debug
/*    if((_base_frame_no<=3840)&&(_base_frame_no+_n_frames>=4096))
    {
       mark_inaccessible(3840,256);
    }
    else if((_base_frame_no>=3840)&&(_base_frame_no<4096))
    {
       unsigned long right_side=_base_frame_no+_n_frames-4096>=0 ? 4096:(_base_frame_no+_n_frames);
       mark_inaccessible(_base_frame_no,right_side-_base_frame_no);
    }
    else if((_base_frame_no+_n_frames<4096)&&(_base_frame_no+_n_frames>=3840))
    {
       unsigned long left_side=_base_frame_no-3840>=0 ? _base_frame_no : 3840;
       mark_inaccessible(left_side,_base_frame_no+_n_frames-left_side);
    }   // Considering the framepool has an overlap with memory hole 15-16M
*/
   // Console::puts("nframes ="); Console::puti(nframes); Console::puts("\n"); //Debug
    //Console::puts(" nFreeFrames ="); Console::puti(nFreeFrames); Console::puts("\n"); //Debug
                 
                    
    Console::puts("Frame Pool initialized\n");
    //assert(false);
                  
}



unsigned long ContFramePool::get_frames(unsigned int _n_frames)
{
    // TODO: IMPLEMENTATION NEEEDED!
      // Any frames left to allocate?
    assert(nFreeFrames > 0);
    
    // Find a frame that is not being used and return its frame index.
    // Mark that frame as being used in the bitmap.
    unsigned long frame_no = base_frame_no;
    unsigned long round_n_frames=(_n_frames%4)>0 ? _n_frames+4-(_n_frames%4) : _n_frames;
    // If _n_frames is not a multiple of 4, we make it round up to be the nearest mu;tiple of 4. We always find number of round_n_frames to simplify
    unsigned int i = 0, hitting_target = 0;
    if(_n_frames==1)
    {
      unsigned int index;
      while(((i*4+_n_frames) <= nframes) && (hitting_target==0))
      {
           unsigned char searcher = 0xC0;
           for(unsigned int j = 0; j < 4; j++)          
           {
              if((searcher&bitmap[i]) != 0)
                searcher = searcher>>2;
              else
              {
                hitting_target = 1; 
                bitmap[i] = bitmap[i] | (0x40>>(2*j));
                index = j;
                break; 
              }       
           }
           i++;
      }    
      if(hitting_target==0)
      { 
        Console::puts("Error, We don't get even one single free frame in this frame pool\n");
        return 0;
      }
      //assert(hitting_target==1);
      frame_no = frame_no + 4*(i-1) + index;
      return (frame_no);
             
    }   
    //For _n_frames>1
    while(((i*4+_n_frames) <= nframes) && (hitting_target==0))
    {
         
         while(((bitmap[i]&0xC0)!=0) && ((i*4+_n_frames) <= nframes))     // 11 00 00 00
              i++;
      // Console::puts("We find a free HEAD is "); Console::puti(i); Console::puts("\n"); //Debug
    //It means there must be some 01 or 10 in the first frame of 4 frames mapping in bitmap[i] , reflecting theHEAD OF SEQUENCE or ALLOCATION.
    // We always want to find a free frame which is the first frame of 4 frames mapping in bitmap[i]
         if (i*4+_n_frames>nframes)
         { 
            hitting_target=0;
            break;
         } // At the end, not hitting  
        
         frame_no += i * 4; //We find a HEAD OF SEQUENCE, but not sure it has enough following consecutive free frames
    
    /*
    unsigned char mask = 0x03;// 00 00 00 11
    while ((mask & bitmap[i-1]) == 0) {
        mask = mask << 2;
        frame_no--;
    }
    // We can find the first free frame if bitmap[i-1] has some free frames to decrease fregments. However, to simplify, we always find consecutive frames
    // the head of which is a multiple of 4
    */
    
         unsigned int bitmap_index;
         for(bitmap_index=1; bitmap_index*4<round_n_frames; bitmap_index ++)
         {       
         if(bitmap[i+bitmap_index-1]!=0x0)
           break;//Not enough consecutive frames or not enough frames left in frame pool           
         }  // Console::puts("bitmap_index= "); Console::puti(bitmap_index); Console::puts("\n"); //Debug 
         if(bitmap_index*4==round_n_frames )
         {// enough (round_n_frames-4) consecutive frames
     // Console::puts("We find at least "); Console::puti(bitmap_index*4-4); Console::puts(" consecutive frames\n"); //Debug 
     // unsigned char mask=_n_frames%4>0 ? 0xFF>>(2*(_n_frames%4)): 0x00;
     //////  Console::puts("We find at least "); Console::puti(bitmap_index*4-4); Console::puts(" consecutive frames for");Console::puti(_n_frames); Console::puts(" frames\n"); //Debug   // 11 11 11 11
     ////// Console::puts("We find HEAD OF SEQUENCE is "); Console::puti(i); Console::puts(" \n"); 
     // Console::puts("bitmap[i+bitmap_index-1]= "); Console::puti((unsigned int)bitmap[i+bitmap_index-1]); Console::puts(" \n"); //Debug
           if((bitmap[i+bitmap_index-1])==0x00)
           {   // This means we have _n_frames%4 or 4 consecutive 00 in bitmap[i+bitmap_index-1], We success getting _n_frames frames
             hitting_target=1;
             if(_n_frames<4)
             {
               bitmap[i]=0x40;
               for(unsigned int j=1; j<_n_frames%4;j++)
               bitmap[i]=bitmap[i]|(0x80>>2*j);
             }
             else if(_n_frames==4)
               bitmap[i]=0x6A;  
             else
             {  // _n_frames>4 
               bitmap[i]=0x6A;  // 01 10 10 10
               for(unsigned int j=1; j<bitmap_index-1;j++)
                  bitmap[i+j]=0xAA;
               unsigned int Mask=(_n_frames%4>0) ? (_n_frames%4) : 4;                                   
               for(unsigned int j=0;j<Mask;j++)
                  bitmap[i+bitmap_index-1]=(bitmap[i+bitmap_index-1])|(0x80>>(2*j));
                                         
             }                                   
                                          
           }  // Hitting the target
      
           else{ //Not hitting, only _n_frames%4 is needed, regreted
             hitting_target=0;
             i=i+bitmap_index;  // Let i skip this hitting failure area
               }
         }
         else
         {
           hitting_target=0; //Not hitting
           i=i+bitmap_index;  // Let i skip this hitting failure area

         }
        
   
    }






    if(hitting_target==0)
    {
      Console::puts("Error, We don't get enough consecutive frames in thsi frame pool\n");   
      return 0;
    } 
  
   // assert(hitting_target==1);
                                      
    return (frame_no); 
   
    // assert(false);
}


void ContFramePool::mark_inaccessible(unsigned long _frame_no)
{
    // TODO: IMPLEMENTATION NEEEDED!
   // assert(false);
    assert ((_frame_no >= base_frame_no) && (_frame_no < base_frame_no + nframes));
    
    unsigned int bitmap_index = (_frame_no - base_frame_no) / 4;
    unsigned char mask = 0x40 >>(2*((_frame_no - base_frame_no) % 4));  // We mark all inaccessible frames as 01
    
    // Is the frame being used already?   If it is already 01 or 10, this means it has been allocated, ERROR  
    assert((bitmap[bitmap_index] & mask) == 0);
    
    // Update bitmap
    bitmap[bitmap_index] = bitmap[bitmap_index]| mask;
   //  nFreeFrames--;  // We should not subtract twicw


}





void ContFramePool::mark_inaccessible(unsigned long _first_frame_no,
                                      unsigned long _n_frames)
{
    // TODO: IMPLEMENTATION NEEEDED!
   // assert(false);
    unsigned int i ;
    for(i = _first_frame_no; i < _first_frame_no + _n_frames; i++)
    {
       mark_inaccessible(i);
    }
    nFreeFrames -= _n_frames;


}



void ContFramePool::inner_release_frames(unsigned long _first_frame_no)
{
                           
   unsigned int bitmap_index = (_first_frame_no - base_frame_no) / 4;
   unsigned char mask = 0x40 >>(2*((_first_frame_no - base_frame_no) % 4)); //The mask tells us where the _first_frame_no mapping in bitmap[bitmap_index]  
   unsigned int ReleaseFrames=0;//We record how many frames have we released
   unsigned int ReleaseMark=0; //We use this to mark if the release is end 1 or in process 0
    // Is the frame being HEAD_OF_SEQUENCE?   If it is free or ALLOCATED, the bitmap of which is 00 or 10, ERROR  
    if((bitmap[bitmap_index] & mask) == 0)  
      ReleaseMark=1;//ERROR
    assert((bitmap[bitmap_index] & mask) != 0);

    // Update bitmap                         
    bitmap[bitmap_index] = bitmap[bitmap_index] ^ mask; // We mark _first_frame_no as 00
    nFreeFrames++;
    ReleaseFrames++;
    /////////Console::puts("We have released the HEAD_OF_SEQUENCE, bitmap_index= "); Console::puti(bitmap_index); Console::puts(" frames \n");
         for(unsigned int i=1;i<(4-(_first_frame_no - base_frame_no)%4);i++)
         { // We first handle bitmap[bitmap_index]                    
            unsigned char mask=0x80>>(2*((_first_frame_no - base_frame_no)%4+i));
           /* if((bitmap[bitmap_index] & mask) ==0x0){  // Not 10, not ALLOCATED            
              ReleaseMark=1;
              break;         
            }*/ 
            if((bitmap[bitmap_index] & mask) !=0x0)
            {   // Update bitmap                         
              bitmap[bitmap_index] = (bitmap[bitmap_index])^(mask);     
              nFreeFrames++;
              ReleaseFrames++;                  
            }
            else
            { //((bitmap[bitmap_index] & mask) ==0x0){  // Not 10, not ALLOCATED            
              ReleaseMark=1;
              break;
            }
         
         } // If bitmap[bitmap_index] has been handled and has been successfully freed since the _first_frame_no  
    bitmap_index++;
    while((ReleaseMark==0)&&(bitmap_index*4<nframes))
    {
         for(unsigned int i=0;i<4;i++)
         {
            unsigned char mask=0x80>>(2*i);                   
            /* if( (bitmap[bitmap_index] & mask) ==0x0 ){  // Not 10, not ALLOCATED            
               ReleaseMark=1;
               break;
               } */
            if((bitmap[bitmap_index] & mask) !=0x0)
            {   // Update bitmap                         
              bitmap[bitmap_index] = (bitmap[bitmap_index])^(mask);// 10 -> 00
              nFreeFrames++;
              ReleaseFrames++;
            }
            else
            {//( (bitmap[bitmap_index] & mask) ==0x0 ){  // Not 10, not ALLOCATED            
              ReleaseMark=1;
              break;
            }      
         }             
         bitmap_index++;              
                             
    }                   
    Console::puts("We have released "); Console::puti(ReleaseFrames); Console::puts(" frames \n");
                                             
}                         



void ContFramePool::release_frames(unsigned long _first_frame_no)
{
   // TODO: IMPLEMENTATION NEEEDED!
   // assert(false);
   assert(number_of_framepools>0);
   ContFramePool *p=head_of_list;
   for(unsigned int i=0;i<number_of_framepools;i++)
   {//We search all frame pools to find which frame pool the _first_frame_no belongs to
      if((_first_frame_no>=(p->base_frame_no))&&(_first_frame_no<(p->base_frame_no+p->nframes)))
      {
        p->inner_release_frames(_first_frame_no);
        break;
      } 
      else      
        p=p->next;
      
      if(p==NULL)
        Console::puts("We don't find such a frame in these frame pools. ERROR ");
      //assert(p!=NULL);     
              
   }                 
                                                                          
}



unsigned long ContFramePool::needed_info_frames(unsigned long _n_frames)
{
    // TODO: IMPLEMENTATION NEEEDED!
   /*
     Returns the number of frames needed to manage a frame pool of size _n_frames.
     The number returned here depends on the implementation of the frame pool and 
     on the frame size.
     EXAMPLE: For FRAME_SIZE = 4096 and a bitmap with a single bit per frame 
     (not appropriate for contiguous allocation) one would need one frame to manage a 
     frame pool with up to 8 * 4096 = 32k frames = 128MB of memory!
     This function would therefore return the following value:
       _n_frames / 32k + (_n_frames % 32k > 0 ? 1 : 0) (always round up!)
     Other implementations need a different number of info frames.
     The exact number is computed in this function..
     */
     return (_n_frames / 16384 + (_n_frames % 16384 > 0 ? 1 : 0));
    //assert(false);
}

