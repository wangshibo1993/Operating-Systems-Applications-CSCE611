/*
 File: vm_pool.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "vm_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   V M P o o l */
/*--------------------------------------------------------------------------*/

VMPool::VMPool(unsigned long  _base_address,
               unsigned long  _size,
               ContFramePool *_frame_pool,
               PageTable     *_page_table) 
{
    base_address = (_base_address & 0xFFFFF000);  //We make the VMPool align in 4kB
    size = _size/(PageTable::PAGE_SIZE);  //page size
    frame_pool = _frame_pool;
    page_table = _page_table;
    next = NULL;      
    region_no = 0;
    page_table -> register_pool(this);
    region_descriptors = (unsigned long*) _base_address;
    
    for(unsigned long i = 0; i < 1024; i++)
       region_descriptors[i] = 0;
   
    for(unsigned long i = 0; i < 1024; i++)
       if((region_descriptors[i]) != 0)
         Console::puts("region_descriptors allocation failed\n");
    
   // Console::puts("region_descriptors ="); Console::puti((unsigned long)region_descriptors); Console::puts("\n");       
    // asser(false);
    Console::puts("Constructed VMPool object.\n");
}

unsigned long VMPool::read_region_no()
{
    return region_no;
}

unsigned long VMPool::allocate(unsigned long _size)
{   
    unsigned long int allocate_successful = 0;
    unsigned long int required_pages = _size/(PageTable::PAGE_SIZE) + (_size % (PageTable::PAGE_SIZE) > 0 ? 1 : 0); 
    if(_size > (size << 12))
    { 
      Console::puts("Fail to allocate region of memory.\n");
      return 0;
    }

    if(region_no == 0)
    {
      region_descriptors[0] = base_address + (1<<12); // initial address
      region_descriptors[1] = required_pages;  //size in page unit
      region_no++;
     // Console::puts("Allocated region of memory.\n");
      Console::puts("region_no ="); Console::puti(region_no); Console::puts("\n");             
      return region_descriptors[0];     
    }
       
   /* else if((region_descriptors[2*(region_no)-2] + (region_descriptors[2*(region_no)-1] << 12)) > (base_address + (size << 12) - (required_pages << 12)))// Beyong the boundry
    { 
      Console::puts("Fail to allocate region of memory.\n");
      return 0;
    }*/

    else //For regino_no >=1, we have already allocated at least one region
    { 
      if((region_descriptors[2*(region_no)-2] + (region_descriptors[2*(region_no)-1] << 12) ) <= (base_address + (size << 12) - (required_pages << 12)))    
      {
        region_descriptors[2*region_no] = region_descriptors[2*(region_no)-2] + (region_descriptors[2*(region_no)-1] << 12); 
        // Calculate the initial address of this new allocated address and set it at the end of the region_descriptors
        region_descriptors[2*region_no + 1] = required_pages;
        region_no++;
       // Console::puts("Allocated region of memory.\n");
        Console::puts("region_no ="); Console::puti(region_no); Console::puts("\n");
        return region_descriptors[2*region_no - 2];

      }

      else if((region_descriptors[0] - base_address - (1<<12)) >= (required_pages << 12))
      {
        for(unsigned long j = region_no; j > 0; j--)  // After release, we update the region_descriptors
        {
            region_descriptors[2*j] = region_descriptors[2*j - 2];
            region_descriptors[2*j +1] = region_descriptors[2*j - 1];
        }
        region_descriptors[0] = base_address + (1<<12);
        region_descriptors[1] = required_pages;
       // Calculate the initial address of this new allocated address and set it at the beginning of the region_descriptors
        region_no++;
        //Console::puts("Allocated region of memory.\n");
        Console::puts("region_no ="); Console::puti(region_no); Console::puts("\n");
        return region_descriptors[0];

      }   
      else
      {
        for(unsigned long j = 1; j < region_no; j++)
        {
           if((region_descriptors[2*j - 2] + (region_descriptors[2*j - 1] << 12) + (required_pages << 12)) <= region_descriptors[2*j])
           {
             for(unsigned long i = region_no; i > j; i--)  // After release, we update the region_descriptors
             {
                region_descriptors[2*i] = region_descriptors[2*i - 2];
                region_descriptors[2*i +1] = region_descriptors[2*i - 1];
             }
             region_descriptors[2*j] = region_descriptors[2*j - 2] + (region_descriptors[2*j - 1] << 12);
             region_descriptors[2*j + 1] = required_pages;   
             region_no++;
             //Console::puts("Allocated region of memory.\n");
             Console::puts("region_no ="); Console::puti(region_no); Console::puts("\n");
             return region_descriptors[0];
  
           }
        } 
      }

    }   
    if(allocate_successful == 0)
      return 0;  
   // Console::puts("Allocated region of memory.\n");
}







void VMPool::release(unsigned long _start_address) 
{
    for( unsigned long i = 0; i < region_no; i++)
    {         
       if(region_descriptors[2*i] == _start_address)
       {
         for(unsigned long j = 0; j < (region_descriptors[2*i + 1]); j++) //tranfer from byte size to page number
            page_table -> free_page(((_start_address) >> 12) + j); //transfer from start sddress to page number      
         
         //region_descriptors[2*i] = 0;
         //region_descriptors[2*i + 1] = 0;
         
         for(unsigned long j = i; j < region_no - 1; j++)  // After release, we update the region_descriptors
         {
            region_descriptors[2*j] = region_descriptors[2*j + 2];
            region_descriptors[2*j +1] = region_descriptors[2*j + 3];
         }
         
         region_no--;
         break;
            
       }        

    }  
    Console::puts("region_no ="); Console::puti(region_no); Console::puts("\n");
    Console::puts("Released region of memory.\n");
}



 

bool VMPool::is_legitimate(unsigned long _address)
{
    unsigned long hitting_target = 0;
    //Console::puts("We are out.\n");
    //Console::puts("_address ="); Console::puti(_address); Console::puts("\n");
    //Console::puts("base_address ="); Console::puti(base_address); Console::puts("\n");
    //Console::puts("base_address + size << 12 ="); Console::puti(base_address + (size << 12)); Console::puts("\n"); 
    if((base_address <= _address) && (_address <= base_address + (size << 12)))
    { 
      //Console::puts("We enter in.\n");
      for(unsigned long i = 0; i < region_no; i++)   
      {    
         if((region_descriptors[2*i] <= _address) && (_address <= region_descriptors[2*i] + (region_descriptors[2*i + 1] << 12)))
         {
           hitting_target = 1;
           break;
         }         
      }   

      //Console::puts("Checked whether address is part of an allocated region.\n");     
    }

    
    if(hitting_target == 1)
      return true;
    else 
      return false;


}


