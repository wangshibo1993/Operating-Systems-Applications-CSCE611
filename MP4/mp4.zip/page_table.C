#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"



//static VMPool* PageTable::head_of_list = NULL;
//static unsigned int PageTable::number_of_registered_vmpools = 0;

 
PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;


void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
    kernel_mem_pool  = _kernel_mem_pool;
    process_mem_pool = _process_mem_pool;   
    shared_size = _shared_size;
    Console::puts("Initialized Paging System\n");
}



PageTable::PageTable()
{   
    head_of_list = NULL;
    number_of_registered_vmpools = 0;
    page_directory=(unsigned long *) ((process_mem_pool->get_frames(1))*4096);
    //Console::puts("page_directory_frame_number ="); Console::puti(((unsigned long)page_directory)>>12); Console::puts("\n"); 
    page_directory[1023] = (((unsigned long) page_directory) | 0x3);  //the last entry of PD is the address of this PD;011  kernel level, read/write, present

    for(unsigned int i=0; i<1023; i++)
    {
       page_directory[i] = 0x2; //At this moment page table page is not constructed, so directory is null. We set kernel level, read/write, not present
    }
   
    unsigned long *page_table_page;
    unsigned long address=0; // holds the physical address of where a page is
    unsigned int i;// We use i to record how many page table pages we need to store the shared memory. One page table page for 4MB memory
   
   // map the shared size of memory
    for(i=0; i<(shared_size >> 22); i++)
    {  
       page_directory[i]=((process_mem_pool->get_frames(1))<<12) | 0x3; //011  kernel level, read/write, present
       //Console::puts("page_table_page_frame_number ="); Console::puti((page_directory[i])>>12); Console::puts("\n");
       page_table_page = (unsigned long *) ((page_directory[i]>>12)<<12);
      
       for(unsigned int j=0; j<ENTRIES_PER_PAGE; j++)
       {
          page_table_page[j] = address | 0x3; // attribute set to: kernel level, read/write, present(111 in binary)
          address = address + 4096; // 4096 = 4kb
       }
   
    }


    Console::puts("Constructed Page Table object\n");
}




void PageTable::load()
{
    current_page_table = this; 
   // write_cr3, read_cr3, write_cr0, and read_cr0 all come from the assembly functions
    write_cr3((unsigned long)page_directory);
   
    Console::puts("Loaded page table\n");
}



void PageTable::enable_paging()
{
    paging_enabled = 1;       
    write_cr0(read_cr0() | 0x80000000); 
    Console::puts("Enabled paging\n");
}




void PageTable::handle_fault(REGS * _r)
{     
    if((paging_enabled == 0) || (current_page_table == NULL)) 
    {
      Console::puts("Current page is not loaded or enabled\n"); 
      assert(false);   
    }
    unsigned long causing_page_fault_address=read_cr2();
    VMPool* pointer = current_page_table->head_of_list;// We maintain an VMPool list
    unsigned long is_legitimate = 0;
    for(unsigned long int i = 1; i < (current_page_table->number_of_registered_vmpools); i++)
    {
      if(pointer->is_legitimate(causing_page_fault_address))
      {
        unsigned long is_legitimate = 1;
        break;
      } 
      pointer = pointer->next;
    }
    assert((is_legitimate != 1));
    Console::puts("causing_page_fault_address ="); Console::puti(causing_page_fault_address); Console::puts("\n");   
    //unsigned long pf_addr=read_cr2();   
    unsigned long PDE_index = causing_page_fault_address >> 22;
    unsigned long PTE_index =((causing_page_fault_address) & 0x3FF000) >> 12;		
    //We construct two pointers to point PD and PT
    unsigned long * page_directory_entry = (unsigned long *)(0xfffff000); 
    unsigned long * page_table_entry = (unsigned long *) ((PDE_index << 12) | 0xffc00000);
    //unsigned long * tmp_addr = 0;

    if( (page_directory_entry[PDE_index] & 0x1) == 0)
    {   
    //if no any entry in this PDE. (bit0=0, non-valid), need to locate mem for this PDE(with 1024 PTEs)
      unsigned long new_pt_phy_address = (process_mem_pool->get_frames(1)) * PAGE_SIZE;
			//tmp_addr = (unsigned long *) (process_mem_pool->get_frames(1)* PAGE_SIZE);  //assign mem for this PDE's page table
			//pf_page_dir[pf_page_dir_index] = ((unsigned long)tmp_addr)| 3;
      page_directory_entry[PDE_index] = (new_pt_phy_address) | 0x3;
      for(unsigned long i = 0; i< ENTRIES_PER_PAGE; i++)
      {
	 page_table_entry[i] = 0x2;
         //pf_page_table[i] = 2 ;  //init 1024 PTEs for this PDE as 010 (kernel mode + RW + non-valid)
      }

    }
		
    unsigned long new_page_phy_address = (process_mem_pool->get_frames(1)) * PAGE_SIZE; 	
    	//map memory from process frame pool to miss page
	//	tmp_addr = (unsigned long *) (process_mem_pool->get_frames(1)* PAGE_SIZE);
    page_table_entry[PTE_index] = (new_page_phy_address) | 0x3 ;  //011 (kernel mode + RW + valid)	

   // Console::puts("handled page fault\n");

}





void PageTable::register_pool(VMPool * _vm_pool)
{
     if(head_of_list == NULL)
       head_of_list = _vm_pool;

     else
     {
       VMPool * pointer = head_of_list;
       for(unsigned int i = 1; i < number_of_registered_vmpools; i++)
          pointer = pointer->next;
       pointer->next = _vm_pool;
     }
     
     number_of_registered_vmpools++;   
     Console::puts("This VMPool is registered\n");

}






void PageTable::free_page(unsigned long _page_no)
{   
   
     unsigned long  PDE_index = _page_no >> 10; 
     unsigned long  PTE_index = ((_page_no << 12) & 0x3FF000) >> 12;
     unsigned long* page_directory_entry = (unsigned long *)(0xfffff000);
     unsigned long* page_table_entry = (unsigned long*)(0xFFC00000 | ( PDE_index << 12));
                     
     if(((page_directory_entry[PDE_index] & 0x1) == 0x0) || ((page_table_entry[PTE_index] & 0x1) == 0x0)); 
      // Console::puts("This page is not valid, we don't need to do anything\n");      

     else
     {
       unsigned long frame_no= (page_table_entry[PTE_index])>>12;
       ContFramePool::release_frames(frame_no);
       page_table_entry[PTE_index] = (page_table_entry[PTE_index]) ^ 0x1;  //clear valid bit[0]
       write_cr3((unsigned long)page_directory);
      // Console::puts("The page is freed\n");
     }	

}




















