#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"

PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;



void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{  
   kernel_mem_pool  = _kernel_mem_pool;
   process_mem_pool = _process_mem_pool;   
   shared_size = _shared_size;
   
  // assert(false);
   Console::puts("Initialized Paging System\n");


}



PageTable::PageTable()
{
   //assert(false);
   // current_page_table = this;            
   page_directory=(unsigned long *) ((kernel_mem_pool->get_frames(1))*4096);


  // for(unsigned int i=0; i<shared_size/(4*1024*1024); i++)
  // {
  //    page_directory[i]=kernel_mem_pool->get_frames(1);
  // }
   
   
   unsigned long *page_table_page;
   unsigned long address=0; // holds the physical address of where a page is
   unsigned int i;// We use i to record how many page table pages we need to store the shared memory. One page table page for 4MB memory
   
   // map the shared size of memory
   for(i=0; i<(shared_size>>22); i++)
   {  
      page_directory[i]=((kernel_mem_pool->get_frames(1))<<12) | 0x3;
      page_table_page =(unsigned long *) ((page_directory[i]>>12)<<12);
      for(unsigned int j=0; j<1024; j++)
      {
         page_table_page[j] = address | 0x3; // attribute set to: supervisor level, read/write, present(011 in binary)
         address = address + 4096; // 4096 = 4kb
      }
   }

   for(unsigned int j=i; j<1024; j++)
   {
      page_directory[j] = 0x0 | 0x6; // For other unmapped frames, attribute set to: user level, read/write, not present(010 in binary)
   }

   Console::puts("Constructed Page Table object\n");
}



void PageTable::load()
{
   current_page_table = this; 
   // write_cr3, read_cr3, write_cr0, and read_cr0 all come from the assembly functions
   write_cr3((unsigned long)page_directory); // put that page directory address into CR3

   // assert(false);
   Console::puts("Loaded page table\n");
}



void PageTable::enable_paging()
{
   paging_enabled = 1;       
   write_cr0(read_cr0() | 0x80000000); // set the paging bit in CR0 to 1            
                                    
   //assert(false);
   Console::puts("Enabled paging\n");
}



void PageTable::handle_fault(REGS * _r)
{
  if((paging_enabled == 0) || (current_page_table == NULL)) 
{
    Console::puts("Current page is not loaded or enabled\n"); 
    assert(false);   
}       
  unsigned long causing_page_fault_address=read_cr2(); 
  //The 32-bit address of the address that caused the page fault is stored in register CR2, and can be read using the function read cr2().        
  //Console::puts("causing_page_fault_address ="); Console::puti(causing_page_fault_address); Console::puts("\n"); 
  //First we search page_directory to make sure whether the page table page is in the directory
  if(current_page_table->page_directory[causing_page_fault_address>>22]==0x6) //Not yet. We need to build PDE
  { 
     current_page_table->page_directory[causing_page_fault_address>>22]=((kernel_mem_pool->get_frames(1))<<12) | 0x3; // kernel mode, write, present
     unsigned long* page_table_page=(unsigned long*) (((current_page_table->page_directory[causing_page_fault_address>>22])>>12)<<12);
     for(unsigned int i=0; i<1024; i++)
        page_table_page[i]=0x6;  //user mode, write, not present
     page_table_page[(causing_page_fault_address & 0x3FF000)>>12]=((process_mem_pool->get_frames(1))<<12) | 0x7;//user mode, write, present
  }

  else if((current_page_table->page_directory[causing_page_fault_address>>22] & 0x1) != 0)//if()// PDE already exists. We need to build PTE
  {  
     unsigned long* page_table_page=(unsigned long*) (((current_page_table->page_directory[causing_page_fault_address>>22])>>12)<<12);         
     page_table_page[(causing_page_fault_address & 0x3FF000)>>12]=((process_mem_pool->get_frames(1))<<12) | 0x7; //user mode, write, present
     //Console::puts("check data ="); Console::puti(page_table_page[causing_page_fault_address & 0x3FF000]); Console::puts("\n");
  }
  //We execute the page number and get a free frame from kernel frame pool
          
                
  Console::puts("handled page fault\n");
}



























