/*
     File        : file_system.C

     Author      : Riccardo Bettati
     Modified    : 2017/05/01

     Description : Implementation of simple File System class.
                   Has support for numerical file identifiers.
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file_system.H"
#include "file.H"
#include "simple_disk.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

/*
struct inode {

       unsigned int file_ID;
       unsigned int file_size;
       unsigned int file_start_block_index;
       unsigned int dummy;  //Just make alignment to multiple of 16

}


     unsigned int size;
     unsigned int file_count;
     unsigned int next_assigned_free_block_index;
     unsigned int max_inode_index;
     unsigned int directory_block;

     unsigned char inode_list[480];
*/



FileSystem::FileSystem() {
    
    Console::puts("In file system constructor.\n");
    disk = NULL;
    size = 0;
    file_count = 0;
    next_assigned_free_block_index = 0;
    max_inode_index = -1;
    directory_block=-1;
    memset(inode_list, 0x0, 480);

    //We have 496*8=3968 inodes. Each inode needs 16 byte, and each bloch has 32 inodes. So we need another 124 blocks to store all inodes. 
    
}

/*--------------------------------------------------------------------------*/
/* FILE SYSTEM FUNCTIONS */
/*--------------------------------------------------------------------------*/

bool FileSystem::Mount(SimpleDisk * _disk) {
     Console::puts("mounting file system form disk\n");
     
     disk = _disk;
     unsigned  int buffer[128]; //Use this as buffer to make disk read and write
     memset(buffer, 0, 512);
     disk->read(0, (unsigned char*)buffer);
      
     size = buffer[0];  //Console::puti(size);Console::puts("\n");
     file_count = buffer[1];  //Console::puti(file_count);Console::puts("\n");
     next_assigned_free_block_index = buffer[2];  //Console::puti(next_assigned_free_block_index);Console::puts("\n");
     max_inode_index = buffer[3];   //Console::puti(max_inode_index );Console::puts("\n");
     directory_block = buffer[4];
     memcpy(inode_list, buffer+8, 480);

     return true;     
     

}

bool FileSystem::Format(SimpleDisk * _disk, unsigned int _size) {
     
     Console::puts("formatting disk\n");
     if((_disk->size()/512) <=16)
     {
       return false;
     }
     unsigned int buffer[128]; //Use this as buffer to make disk read and write
     //memset(buffer, 0, 512);
     //Console::puts("Use this as buffer to make disk read and write\n");
    // for(int i=0; i<128; i=i+4)
      //  buffer[i] = -1;
        
     //for(int i=1; i<=15; ++i)
      //  _disk->write(i, (unsigned char*)buffer);//Initialize all inodes with their file_ID as -1

    /* for(int i=0; i<128; i=i+1)
     { Console::puti( buffer[i]);              }
     Console::puts("\n");
     Console::puts("Initialize all inodes with their file_ID as -1\n");*/
     memset(buffer, 0, 512);
 
     for(int i=16; i<(_size/512)-1; ++i)
     {
        buffer[127]=i+1;
        if(i%200 == 0)
        {Console::puts("% ");Console::puti(i*100/(_size/512));Console::puts(" is formatted\n ");} 
        _disk->write(i, (unsigned char*)buffer);
        
     }
     
     buffer[127]=-1;
     _disk->write((_size/512)-1, (unsigned char*)buffer);  //-1 is set as the pointer of next data block in the last data block
     Console::puts("% 100 is formatted\n ");
     //Console::puts("-1 is set as the pointer of next data block in the last data block\n");     
     memset(buffer, 0, 512);  // Now we need to write the block 0, which is superblock
     buffer[0] =_size; //size
     buffer[1] = 0;  // file_count
     buffer[2] = 16; // file_start_block_index;
     buffer[3] = -1; // max_inode_index, -1 as default
     buffer[4] = -1;
     //Console::puts("Now we need to write the block 0, which is superblock\n");

     _disk->write(0, (unsigned char*)buffer);

     return true;

}


unsigned int FileSystem::get_free_inode(){
     
     //unsigned int buffer[128];
     
     
     for(int i=0; i<480; ++i)
     {
        if( inode_list[i] == 0)
        {
          inode_list[i]=1;
          max_inode_index = (i>max_inode_index) ? i:max_inode_index;
         /* 
          unsigned int buffer[128];
          buffer[0] = size;
          buffer[1] = file_count;
          buffer[2] = next_assigned_free_block_index;
          buffer[3] = max_inode_index;
          buffer[4] = directory_block;
          memcpy(buffer+8, inode_list, 480);

          disk->write(0, (unsigned char*)buffer);//We need to update the disk
          */
          //Console::puts("We get free_inode  ");Console::puti(i);Console::puts("\n");
          return i;
        }

        else
          continue;
     }
     
     return -1;

}


unsigned int FileSystem::get_free_block(){

      unsigned int buffer[128];
      unsigned int free_block = next_assigned_free_block_index; 
      disk->read(next_assigned_free_block_index, (unsigned char*)buffer);
      next_assigned_free_block_index = buffer[127];//We need to update next_assigned_free_block_index
      buffer[127]=-1;
      disk->write(free_block, (unsigned char*)buffer);//Clear the tail of free block because it will be used as a tail of a file, thus it should not be in the free block link list 
      //Console::puts("next_assigned_free_block_index is ");Console::puti( next_assigned_free_block_index);Console::puts("\n");
     /* buffer[0] = size;
      buffer[1] = file_count;
      buffer[2] = next_assigned_free_block_index;
      buffer[3] = max_inode_index;
      buffer[4] = directory_block;
      memcpy(buffer+8, inode_list, 480);

      disk->write(0,(unsigned char*) buffer);
      */
      //Console::puts("We get free_block  ");Console::puti( free_block);Console::puts("\n");
      return free_block;

}


void FileSystem::free_inode(int allocated_inode){

     if(allocated_inode<0 || allocated_inode >=480)
     {   Console::puts("Error\n");  return;   }

     inode_list[allocated_inode]=0;

    /* unsigned int buffer[128];
     buffer[0] = size;
     buffer[1] = file_count;
     buffer[2] = next_assigned_free_block_index;
     buffer[3] = max_inode_index;
     buffer[4] = directory_block;
     memcpy(buffer+8, inode_list, 480);

     disk->write(0,(unsigned char*) buffer); 
     */
     //Console::puts("inode is freed successfully\n");
     return;


}





void FileSystem::free_block( int allocated_block){
     
     if(allocated_block<0)
     {   Console::puts("Error\n");  return;   }

     
     unsigned int buffer[128];
     buffer[127] = next_assigned_free_block_index;
     disk->write(allocated_block,(unsigned char*) buffer);     
     next_assigned_free_block_index = allocated_block;
     
     /*
     buffer[0] = size;
     buffer[1] = file_count;
     buffer[2] = next_assigned_free_block_index;
     buffer[3] = max_inode_index;
     buffer[4] = directory_block;
     memcpy(buffer+8, inode_list, 480);
      
     disk->write(0,(unsigned char*) buffer);
     */
     //Console::puts("block is freed successfully\n");
     return;
}






File * FileSystem::LookupFile(int _file_id) {
    Console::puts("looking up file ");Console::puti(_file_id);Console::puts("\n");
    if(_file_id <= 0 || file_count<1 || directory_block<0)
     {Console::puts("Oops! we can't find the file ");Console::puti(_file_id);Console::puts("\n"); return NULL;}
    
    unsigned long buffer[128];
    disk->read(directory_block, (unsigned char*)buffer);
    int i;
    for(i=0; i<63; ++i)  // We assume one block is enough to hold all files in the directory, which means at most 63 files
    {
       if(buffer[i*2] == _file_id)
         break;
        
       else
         continue; 
       
    }
   
    if(i<63)
    {
      Console::puts("Hit the target \n ");
      //Console::puts("i= ");Console::puti(i);Console::puts("\n");
      unsigned int file_inode_index = buffer[i*2+1];
      disk->read(1+(file_inode_index/32), (unsigned char*)buffer); //We find which block is this inode in
      assert(buffer[4 * (file_inode_index % 32) ]==_file_id);//check the file ID

      unsigned int file_size = buffer[4 * (file_inode_index % 32) +1];
      unsigned int file_start_block_index = buffer[4 * (file_inode_index % 32) +2];
      File* obj_file = new File(_file_id, file_size, file_start_block_index, file_inode_index, this);
      return obj_file;  
    }
     else
      {Console::puts("Oops! we can't find the file ");Console::puti(_file_id);Console::puts("\n"); return NULL;}
  
    
    
}

bool FileSystem::CreateFile(int _file_id) {
    Console::puts("Creatting file ");Console::puti(_file_id);Console::puts(" \n");
    if(_file_id <= 0 ) 
      return false;
   // unsigned int buffer1[128];
   // unsigned int buffer2[128];
      
      unsigned int buffer[128];
      if(directory_block == -1) // Now we must don't have a directory
      {
         directory_block = get_free_block();
         memset(buffer, 0, 512);
         buffer[127]=-1;
      }
      else
        disk->read(directory_block, (unsigned char*)buffer);//We first get the old version directory;
      
      buffer[file_count*2] = _file_id;
      unsigned int file_inode_index = get_free_inode(); 
      buffer[file_count*2 +1] = file_inode_index;
      disk->write(directory_block, (unsigned char*)buffer); // Now we update the directory
      
      //Now we update the inode
      memset(buffer, 0, 512);
      disk->read(1+(file_inode_index/32), (unsigned char*)buffer);//We first get the old version inode block;
      buffer[4 * (file_inode_index % 32) ] = _file_id; //We set the file_ID
      buffer[4 * (file_inode_index % 32) +1] = 0; //We set the file size
      buffer[4 * (file_inode_index % 32) +2] = get_free_block(); // We set the file_start_block_index
     
      disk->write(1+(file_inode_index/32), (unsigned char*)buffer); //We find which block is this inode in and write this inode into the block
     
     // File* obj_file = new File(_file_id, file_size, file_start_block_index, file_inode_index, this);

    

    
    file_count++;
    buffer[0] = size;
    buffer[1] = file_count;
    buffer[2] = next_assigned_free_block_index;
    buffer[3] = max_inode_index;
    buffer[4] = directory_block;
    memcpy(buffer+8, inode_list, 480);

    disk->write(0, (unsigned char*)buffer);//We need to update the disk

    Console::puts("Now we have ");Console::puti(file_count);Console::puts(" files\n");
    Console::puts("Creat file successfully\n");
    return true;





}









bool FileSystem::DeleteFile(int _file_id) {
    Console::puts("Deleting file ");Console::puti(_file_id);Console::puts(" \n");
    
    if(_file_id <= 0 || file_count<1 || directory_block<0) //File not existed
      {return false;}
     
    unsigned long buffer[128];
    disk->read(directory_block, (unsigned char*)buffer);
    int i;
    for(i=0; i<63; ++i)  // We assume one block is enough to hold all files in the directory, which means at most 63 files
    {
       if(buffer[i*2] == _file_id)
         break;

       else
         continue;

    }
  
    if(i>=63)//File not existed
      return false;
    else//We find it
    {
      file_count--;
      free_inode(buffer[i*2+1]);//We need to free inode;
      unsigned int file_inode_index = buffer[i*2+1];
      buffer[i*2] = 0;
      buffer[i*2+1] = 0;
      disk->write(directory_block, (unsigned char*)buffer);
      //unsigned int file_inode_index = buffer[i*2+1];
      disk->read(1+(file_inode_index/32), (unsigned char*)buffer); //We find which block is this inode in
      assert(buffer[4 * (file_inode_index % 32) ]==_file_id);//check the file ID
      unsigned int file_size = buffer[4 * (file_inode_index % 32) +1];
      unsigned int file_start_block_index = buffer[4 * (file_inode_index % 32) +2];
      //File* obj_file = new File(_file_id, file_size, file_start_block_index, file_inode_index, this);
      
        //memset(buffer, 0, 512);
       //Now we delete the file
        disk->read(file_start_block_index, (unsigned char*)buffer);
        unsigned int next_block_index = buffer[127];
        free_block(file_start_block_index);
        while(next_block_index != -1)//This means we have a next_block
        {
             disk->read(next_block_index, (unsigned char*)buffer);
             free_block(next_block_index);
             next_block_index = buffer[127];
            // free_block(next_block_index);
            
        }    

      

      //assert(!LookupFile( _file_id));
      memset(buffer, 0, 512);
      buffer[0] = size;
      buffer[1] = file_count;
      buffer[2] = next_assigned_free_block_index;
      buffer[3] = max_inode_index;
      buffer[4] = directory_block;
      memcpy(buffer+8, inode_list, 480);

      disk->write(0, (unsigned char*)buffer);//We need to update the disk

      //Console::puts("Now we have ");Console::puti(file_count);Console::puts(" files\n");
      Console::puts("Delete file successfully\n");

      return true;
    }





}
