/*
     File        : file.C

     Author      : Riccardo Bettati
     Modified    : 2017/05/01

     Description : Implementation of simple File class, with support for
                   sequential read/write operations.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/






/*
struct inode {

       unsigned int file_ID;
       unsigned int file_size;
       unsigned int file_start_block_index;
       unsigned int dummy;  //Just make alignment to multiple of 16

}*/






File::File(int _file_ID, unsigned int _file_size, unsigned int _file_start_block_index, unsigned int _file_inode_index, FileSystem* _file_system) {
    /* We will need some arguments for the constructor, maybe pointer to disk
     block with file management and allocation data. */
    Console::puts("In file constructor.\n");
    
    file_ID = _file_ID;
    file_size = _file_size;
    file_start_block_index = _file_start_block_index;
    file_inode_index = _file_inode_index;
    current_location = 0;
    current_block = _file_start_block_index;

    file_system = _file_system; 
    
             
       
        
        

}

/*--------------------------------------------------------------------------*/
/* FILE FUNCTIONS */
/*--------------------------------------------------------------------------*/

int File::Read(unsigned int _n, char * _buf) {
    Console::puts("Reading from file ");Console::puti(file_ID);Console::puts(" \n");
    
    if(file_size == 0 || EoF())
      return 0;
    if(current_location + _n >file_size)//Error check here!!!
    { 
      Console::puts("Boundary violation alarm! We can only read ");Console::puti(file_size - current_location);Console::puts(" characters\n");
      _n=file_size - current_location;
    }
    unsigned int char_read=0;
    unsigned char buffer[512];
    //file_system->disk->read(current_block, (unsigned char*)buffer);
    while(char_read < _n && !EoF())
    {    
         file_system->disk->read(current_block, (unsigned char*)buffer);           
         //unsigned int char_read_in_onr_iteration;
         if( (_n+(current_location%508)-1) <= 507 ) //We are still in current_block
         {
          
            memcpy(_buf+char_read, buffer+current_location, _n);//It will break automatically
            char_read=_n;
            current_location+=_n;

         } 
         else//We need to enter into the second block in this file
         {
                 
           memcpy(_buf+char_read, buffer+(current_location%508), 508-(current_location%508));       
           char_read += 508-(current_location%508);     
           current_location += char_read;
           memcpy(&current_block, buffer+508, 4);//We need move to next_block
         }
    
    }       
            
    //memset(buffer, 0, 512);
    //file_system->disk->read(1+(file_inode_index/32), (unsigned char*)buffer);//We first get the old version inode block;
   // assert(buffer[4 * (file_inode_index % 32) ] == file_ID); //We set the file_ID
    

        
    return char_read;       
        


}


void File::Write(unsigned int _n, const char * _buf) {
    
    Console::puts("Writing to file ");Console::puti(file_ID);Console::puts(" \n");
  /*    unsigned int file_inode_index = buffer[i*2+1];
      disk->read(1+(file_inode_index/32), (unsigned char*)buffer); //We find which block is this inode in
      unsigned int file_size = buffer[4 * (file_inode_index % 32) +1];
      unsigned int file_start_block_index = buffer[4 * (file_inode_index % 32) +2];
      File* obj_file = new File(_file_id, file_size, file_start_block_index, file_inode_index, this);
    */   
           
    if(_n == 0)
      return; 

    if(current_location + _n >file_size)
      file_size = current_location + _n;
    
    unsigned int char_write=0;
    unsigned char buffer[512];
 
    while(char_write < _n)
    {
         file_system->disk->read(current_block, (unsigned char*)buffer);
         //unsigned int char_read_in_onr_iteration;
         if( (_n+(current_location%508)-1) <= 507 )
         {

            memcpy( buffer+current_location, _buf+char_write, _n);//It will break automatically
            char_write=_n;
            current_location += _n;
            file_system->disk->write(current_block, (unsigned char*)buffer);//We need to update the disk

         }

         else//We need to write into another block in this file
         {
           memcpy( buffer+current_location, _buf+char_write, 508-(current_location%508));//First we wite this block to full
           char_write += 508-(current_location%508);
           current_location += char_write;
           
           unsigned int tmp=current_block;
           memcpy(&current_block, buffer+508, 4);
           if(current_block == -1)
           {
             current_block=file_system->get_free_block();
             memcpy(buffer+508, &current_block, 4);
           }
           file_system->disk->write(tmp, (unsigned char*)buffer);//We need to update the disk

         }


    }
    //Now we need to update the inode, but we don't need to update the superblock
    memset(buffer, 0, 512);
    file_system->disk->read(1+(file_inode_index/32), (unsigned char*)buffer);//We first get the old version inode block;
   // assert(buffer[4 * (file_inode_index % 32) ] == file_ID); //We set the file_ID
    memcpy(buffer+16*(file_inode_index % 32)+4, &file_size, 4);
    //buffer[4 * (file_inode_index % 32) +1] = file_size; //We set the file size
    //buffer[4 * (file_inode_index % 32) +2] = get_free_block(); // We do not need to change the file_start_block_index

    file_system->disk->write(1+(file_inode_index/32), (unsigned char*)buffer); //We write this inode back to its block
    /* 
    memset(buffer, 0, 512);   
    buffer[0] = file_system->size;
    buffer[1] = file_system->file_count;
    buffer[2] = file_system->next_assigned_free_block_index;
    buffer[3] = file_system->max_inode_index;
    buffer[4] = file_system->directory_block;
    memcpy(buffer+8, file_system->inode_list, 480);

    file_system->disk->write(0, (unsigned char*)buffer);//We need to update the disk
    */
         
         
         
     
}

void File::Reset() {
    Console::puts("Reset current position in file ");Console::puti(file_ID);Console::puts(" \n");
    current_block=file_start_block_index;
    current_location=0;
    //assert(false);
    
}

void File::Rewrite() {
    Console::puts("Erase content of file\n");Console::puti(file_ID);Console::puts(" \n");
    current_block=file_start_block_index;
    current_location=0;
    file_size=0;   
     unsigned char buffer[512];
    //Now we need to update the inode, but we don't need to update the superblock
    memset(buffer, 0, 512);
    file_system->disk->read(1+(file_inode_index/32), (unsigned char*)buffer);//We first get the old version inode block;
   // assert(buffer[4 * (file_inode_index % 32) ] == file_ID); //We set the file_ID
    memcpy(buffer+16*(file_inode_index % 32)+4, &file_size, 4);
    //buffer[4 * (file_inode_index % 32) +1] = file_size; //We set the file size
    //buffer[4 * (file_inode_index % 32) +2] = get_free_block(); // We do not need to change the file_start_block_index

    file_system->disk->write(1+(file_inode_index/32), (unsigned char*)buffer); //We write this inode back to its block
 
    //assert(false);
}


bool File::EoF() {
    //Console::puts("testing end-of-file condition\n");
    //assert(false);
    return (current_location >= (file_size-1) );
}
