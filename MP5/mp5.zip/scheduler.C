/*
 File: scheduler.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "scheduler.H"
#include "thread.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"
#include "simple_timer.H"
/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   S c h e d u l e r  */
/*--------------------------------------------------------------------------*/


extern SimpleTimer timer(100);

Scheduler::Scheduler()
{
  //assert(false);
  head_number = 0;
  tail_number = 0;
  thread_number = 0;
  Console::puts("Constructed Scheduler.\n");
}



void Scheduler::yield() 
{
  // Console::puts("Ticks is "); Console::puti(timer.getticks()); Console::puts(" \n");
  //assert(false);
  if(Machine::interrupts_enabled())
      Machine::disable_interrupts();

  if(thread_number > 0)
  {
    Thread* next_thread = ready_queue[head_number];
    ready_queue[head_number] = NULL;
    head_number = (head_number + 1) % MAX_NUMBER;
    thread_number--;
    Thread::dispatch_to(next_thread);
  }

  else if(thread_number == 0)
  {
    head_number = 0;
    tail_number = 0;
     Console::puts("All threads are completed and dequeued.\n");
  }

  timer.reset();
  //Console::puts("Ticks is "); Console::puti(timer.getticks()); Console::puts(" \n");
  if(!Machine::interrupts_enabled())
      Machine::enable_interrupts();
 // Console::puts("Now ticks is "); Console::puti(timer.getticks()); Console::puts(" \n");  

}



void Scheduler::resume(Thread * _thread)
{
  if(Machine::interrupts_enabled())   
      Machine::disable_interrupts(); 
  
  ready_queue[tail_number]=_thread;
  tail_number = (tail_number + 1) % MAX_NUMBER;
  thread_number++;
  //assert(false);
}





void Scheduler::add(Thread * _thread)
{
  if(Machine::interrupts_enabled())   
      Machine::disable_interrupts(); 
  ready_queue[tail_number]=_thread;
  tail_number = (tail_number + 1) % MAX_NUMBER;
  thread_number++;
  //assert(false);
}



unsigned long Scheduler::ThreadNumber()
{ 
  return thread_number;
}

void Scheduler::terminate(Thread * _thread) 
{
 // if(!Machine::interrupts_enabled())   
   //   Machine::enable_interrupts(); 
  if(_thread == (Thread::CurrentThread()))
    yield(); 
 /* else 
  { 
    unsigned long i;
    for(i = 0; i < thread_number; i++)   
    {
       if(ready_queue[(head_number + i) % MAX_NUMBER] == _thread)
         break;
    }
    
   for(unsigned long j = i+1; j < thread_number; j++)
   {
      ready_queue[(head_number + i) % MAX_NUMBER]
   }


  }
*/
 //assert(false);
}
